import { Component } from '@angular/core';

@Component({
  selector: 'app-withdrawfund',
  templateUrl: './withdrawfund.component.html',
  styleUrls: ['./withdrawfund.component.css']
})
export class WithdrawfundComponent {

}
