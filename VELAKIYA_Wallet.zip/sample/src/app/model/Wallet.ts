export class Wallet{
    constructor(public id?:number, public name?:string,public balance?:number){}
}